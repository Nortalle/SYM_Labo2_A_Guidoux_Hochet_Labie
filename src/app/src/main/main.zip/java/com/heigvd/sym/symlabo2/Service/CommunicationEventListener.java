package com.heigvd.sym.symlabo2.Service;

public abstract class CommunicationEventListener {
    abstract public void handleServerResponse(String response);
}
